import discord
from discord.ext import commands
import asyncio
import random
from keep_alive import keep_alive
from discord.ui import View, Button
from discord import Permissions
import aiohttp
import datetime



intents = discord.Intents.default()
intents.message_content = True
intents.members = True
intents.reactions = True

bot = commands.Bot(command_prefix="!", intents=intents, help_command=None)

AUTHORIZED_ROLE_IDS = [1399099095691427850, 1398498864885137508]  # Mets ici les IDs autorisés

def is_authorized():
    from discord.ext import commands

    async def predicate(ctx):
        if ctx.guild is None:
            return False
        author_role_ids = [role.id for role in ctx.author.roles]
        if any(role_id in author_role_ids for role_id in AUTHORIZED_ROLE_IDS):
            return True
        await ctx.send("❌ Vous n'avez pas la permission d'utiliser cette commande.")
        return False

    return commands.check(predicate)

@bot.event
async def on_ready():
    print(f"✅ Connecté en tant que {bot.user}")

@bot.command()
@is_authorized()
async def nuke(ctx):
        try:
            old_channel = ctx.channel
            new_channel = await old_channel.clone(reason="Channel nuked")
            await old_channel.delete()
            await new_channel.send("💥 Ce salon a été recréé avec succès !")
        except Exception as e:
            await ctx.send(f"❌ Erreur lors du nuke du salon : {e}")


@bot.command()
async def ping(ctx):
    await ctx.send("🏓 Pong !")

@bot.command()
async def boostify(ctx, *, message: str):
    try:
        await ctx.message.delete()  # Supprime le message d'origine de l'utilisateur
    except:
        pass  # Ignore si pas les permissions

    await ctx.send(message)  # Renvoie le message avec le bot

@bot.event
async def on_message(message):
    if message.author.bot:
        return 

    now = asyncio.get_event_loop().time()
    last_time = antispam_users.get(message.author.id, 0)
    if now - last_time < antispam_delay:
        await message.delete()
        try:
            await message.author.send(
                "⏳ Merci d'attendre avant de renvoyer un message.")
        except:
            pass
        return
    antispam_users[message.author.id] = now

    await bot.process_commands(message)


@bot.event
async def on_member_join(member):
    global bot_protection_enabled
    if not bot_protection_enabled:
        return
    if member.bot:
        try:
            await member.kick(reason="Protection bots activée")
            channel = discord.utils.get(member.guild.text_channels,
                                        name="bienvenue")
            if channel:
                await channel.send(
                    f"⚠️ Le bot {member.name} a été expulsé car la protection bots est activée."
                )
        except:
            pass

reaction_message_channels = {}  # {guild_id: {channel_id: emoji} 


@bot.command()
@commands.has_permissions(administrator=True)
async def setupautoreact(ctx):
    def check_dm(m):
        return m.author == ctx.author and isinstance(m.channel, discord.DMChannel)

    try:
        await ctx.author.send("📩 Configuration de l'autoreact !")

        await ctx.author.send("➡️ Envoie-moi l'ID du salon où tu veux que le bot réagisse automatiquement aux messages :")
        channel_msg = await bot.wait_for('message', check=check_dm, timeout=120)
        channel_id = int(channel_msg.content)

        await ctx.author.send("➡️ Envoie-moi l'emoji à utiliser (unicode ou custom) :")
        emoji_msg = await bot.wait_for('message', check=check_dm, timeout=120)
        emoji = emoji_msg.content

        guild = ctx.guild
        channel = guild.get_channel(channel_id)
        if channel is None:
            await ctx.author.send("❌ Ce salon n'existe pas sur ce serveur.")
            return

        if guild.id not in reaction_message_channels:
            reaction_message_channels[guild.id] = {}

        reaction_message_channels[guild.id][channel_id] = emoji

        await ctx.author.send(f"✅ Configuration réussie : chaque message dans #{channel.name} aura la réaction {emoji} automatiquement.")
        await ctx.send(f"✅ {ctx.author.mention} La configuration d'autoreact est enregistrée. Check tes MP !")

    except asyncio.TimeoutError:
        await ctx.author.send("⏰ Temps écoulé, la configuration a été annulée.")


reaction_roles = {}  # stocke la config sous forme {message_id: {emoji: role_id}}

@bot.command()
@commands.has_permissions(administrator=True)
async def setupreactionrole(ctx):
    def check_dm(m):
        return m.author == ctx.author and isinstance(m.channel, discord.DMChannel)

    try:
        await ctx.author.send("📩 Bonjour ! Commence la configuration du reaction role.")

        # 1. Message ID
        await ctx.author.send("➡️ Envoie-moi l'ID du **message** où tu veux mettre la réaction :")
        msg_id_msg = await bot.wait_for('message', check=check_dm, timeout=120)
        message_id = int(msg_id_msg.content)

        # 2. Emoji
        await ctx.author.send("➡️ Envoie-moi l'**emoji** à utiliser (emoji unicode ou custom) :")
        emoji_msg = await bot.wait_for('message', check=check_dm, timeout=120)
        emoji = emoji_msg.content

        # 3. Role ID
        await ctx.author.send("➡️ Envoie-moi l'ID du **rôle** à attribuer quand on réagit :")
        role_id_msg = await bot.wait_for('message', check=check_dm, timeout=120)
        role_id = int(role_id_msg.content)

        guild = ctx.guild
        role = guild.get_role(role_id)
        if role is None:
            await ctx.author.send("❌ Le rôle avec cet ID n'existe pas sur ce serveur.")
            return

        channel = None
        message = None
        # Trouver le message
        for ch in guild.text_channels:
            try:
                message = await ch.fetch_message(message_id)
                channel = ch
                break
            except:
                continue

        if message is None:
            await ctx.author.send("❌ Message introuvable avec cet ID sur ce serveur.")
            return

        # Ajouter la réaction au message
        try:
            await message.add_reaction(emoji)
        except Exception as e:
            await ctx.author.send(f"❌ Impossible d'ajouter la réaction: {e}")
            return

        # Enregistrer la config
        if message_id not in reaction_roles:
            reaction_roles[message_id] = {}
        reaction_roles[message_id][emoji] = role_id

        await ctx.author.send("✅ Configuration réussie ! Le rôle sera attribué quand quelqu'un réagira avec cet emoji.")

        await ctx.send(f"✅ {ctx.author.mention} La configuration du reaction role a bien été enregistrée. Check tes MP !")

    except asyncio.TimeoutError:
        await ctx.author.send("⏰ Temps écoulé, la configuration a été annulée.")

@bot.event
async def on_message(message):
    if message.author.bot:
        return

    # Garde ta logique anti-spam ici si tu veux
    # ...

    # Auto réaction si salon configuré
    guild = message.guild
    if guild and guild.id in reaction_message_channels:
        channel_reacts = reaction_message_channels[guild.id]
        emoji = channel_reacts.get(message.channel.id)
        if emoji:
            try:
                await message.add_reaction(emoji)
            except Exception as e:
                print(f"Erreur en ajoutant la réaction : {e}")

    await bot.process_commands(message)



@bot.event
async def on_raw_reaction_add(payload):
    if payload.message_id in reaction_roles:
        emoji = str(payload.emoji)
        if emoji in reaction_roles[payload.message_id]:
            guild = bot.get_guild(payload.guild_id)
            if guild is None:
                return
            member = guild.get_member(payload.user_id)
            if member is None or member.bot:
                return
            role_id = reaction_roles[payload.message_id][emoji]
            role = guild.get_role(role_id)
            if role is None:
                return
            await member.add_roles(role)

@bot.event
async def on_raw_reaction_remove(payload):
    if payload.message_id in reaction_roles:
        emoji = str(payload.emoji)
        if emoji in reaction_roles[payload.message_id]:
            guild = bot.get_guild(payload.guild_id)
            if guild is None:
                return
            member = guild.get_member(payload.user_id)
            if member is None or member.bot:
                return
            role_id = reaction_roles[payload.message_id][emoji]
            role = guild.get_role(role_id)
            if role is None:
                return
            await member.remove_roles(role)

@bot.command()
@commands.has_permissions(administrator=True)
async def togglebotprotection(ctx):
    global bot_protection_enabled
    bot_protection_enabled = not bot_protection_enabled
    status = "activée" if bot_protection_enabled else "désactivée"
    await ctx.send(f"🔄 Protection bots {status}.")




@bot.command()
async def embedcustom(ctx):

    def check_dm(m):
        return m.author == ctx.author and isinstance(m.channel,
                                                     discord.DMChannel)

    try:
        # Envoyer le DM
        await ctx.author.send("📝 Quel est le **titre** de l'embed ?")
        titre = (await bot.wait_for('message', check=check_dm,
                                    timeout=60)).content

        await ctx.author.send(
            "💬 Quel est le **texte principal** ? (tu peux utiliser `\\n` pour sauter une ligne)"
        )
        texte = (await bot.wait_for('message', check=check_dm,
                                    timeout=120)).content

        await ctx.author.send("🔻 Quel est le **texte du footer** ?")
        footer = (await bot.wait_for('message', check=check_dm,
                                     timeout=60)).content

        texte = texte.replace("\\n", "\n")

        embed = discord.Embed(title=titre, color=discord.Color.blue())
        embed.add_field(name="\u200b", value=texte, inline=False)
        embed.set_footer(text=footer)

        await ctx.send(embed=embed)
        await ctx.author.send("✅ Embed envoyé dans le salon !")

    except discord.Forbidden:
        await ctx.send(
            "❌ Je n'arrive pas à t’envoyer de message privé. Active tes MP.")
    except asyncio.TimeoutError:
        await ctx.author.send("⏰ Temps écoulé. Recommence la commande.")


@bot.command(name="clear", aliases=["purge", "deletemessages"])
@commands.has_permissions(manage_messages=True)
async def clear_messages(ctx, nombre: int):
    if nombre < 1 or nombre > 100:
        await ctx.send("❌ Tu dois indiquer un nombre entre 1 et 100.")
        return

    try:
        await ctx.channel.purge(
            limit=nombre + 1)  # +1 pour supprimer aussi le message de commande
        confirmation = await ctx.send(f" {nombre} clear")
        await asyncio.sleep(3)
        await confirmation.delete()
    except discord.Forbidden:
        await ctx.send("❌ Je n'ai pas la permission de supprimer les messages."
                       )


@bot.command()
async def giveaway(ctx, temps: int, *, prix: str):
    embed = discord.Embed(
        title="🎉 Giveaway 🎉",
        description=
        f"Réagis avec 🎉 pour participer !\nDurée : {temps} secondes\nPrix : **{prix}**",
        color=discord.Color.green())
    message = await ctx.send(embed=embed)
    await message.add_reaction("🎉")
    await asyncio.sleep(temps)

    message = await ctx.channel.fetch_message(message.id)
    users = [
        user async for user in message.reactions[0].users() if not user.bot
    ]
    if users:
        gagnant = random.choice(users)
        embed_gagnant = discord.Embed(
            title="🎊 Giveaway terminé ! 🎊",
            description=
            f"Félicitations {gagnant.mention}, tu as gagné **{prix}** !",
            color=discord.Color.gold())
        await ctx.send(embed=embed_gagnant)
    else:
        await ctx.send("😢 Personne n'a participé au giveaway...")

    
        
@bot.command()
async def help(ctx):
    embed = discord.Embed(
        title="📚 Commandes disponibles",
        description="Voici les commandes que tu peux utiliser :",
        color=discord.Color.orange()
    )
    embed.add_field(name="!ping", value="Vérifie si le bot répond", inline=False)
    embed.add_field(
        name="!embedcustom",
        value="Crée un embed avec un titre, un texte multi-lignes (`\\n` pour sauts de ligne), et un footer. Le bot te posera les questions.",
        inline=False
        
    )
    embed.add_field(name="!giveaway <temps_en_secondes> <prix>", value="Lance un giveaway", inline=False)
    embed.add_field(name="!togglebotprotection", value="Active/désactive la protection contre les bots (admin)", inline=False)
    embed.add_field(name="!clear <nombre>", value="Supprime plusieurs messages (entre 1 et 100)", inline=False)
    embed.add_field(
        name="!setupreactionrole",
        value="Configure un message pour attribuer un rôle via une réaction emoji. Tu choisis le message, le rôle et l'emoji en MP.",
        inline=False
  
    )
    embed.add_field(
        name="!setupautoreact",
        value="Configure un salon où chaque message recevra automatiquement une réaction emoji choisie (configuration en DM).",
        inline=False
    )
    embed.add_field(name="!reglement", value="Affiche le règlement officiel du serveur.", inline=False)
    embed.add_field(name="!help", value="Affiche ce message", inline=False)

    try:
        await ctx.author.send(embed=embed)
    
    except discord.Forbidden:
        await ctx.send(f"❌ {ctx.author.mention}, je ne peux pas t'envoyer de message privé. Vérifie tes paramètres de confidentialité.")




keep_alive()

# 🚀 Lancer le bot
bot.run(
    "MTM5ODQ5MDk5OTkyNzYwNzQzOQ.GsOePb.i-eb3Z0BSCm72vO2VKBOoNYlduza_15No2x8Fc")
